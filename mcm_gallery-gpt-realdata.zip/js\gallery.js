/**
 * MCM Figures Gallery - Interactive Filtering Logic
 */

(async function () {
  // State
  let images = [];
  let allThemes = [];
  let allTags = [];
  let activeTheme = null;
  let activeTags = new Set();
  let searchQuery = "";
  let filterMode = "AND"; // 'AND' or 'OR'
  let currentLightboxIndex = -1;
  let filteredImages = [];

  // DOM Elements
  const galleryGrid = document.getElementById("galleryGrid");
  const themeFilters = document.getElementById("themeFilters");
  const tagFilters = document.getElementById("tagFilters");
  const searchInput = document.getElementById("searchInput");
  const clearBtn = document.getElementById("clearFilters");
  const modeAndBtn = document.getElementById("modeAnd");
  const modeOrBtn = document.getElementById("modeOr");
  const imageCount = document.getElementById("imageCount");
  const selectedTagsCount = document.getElementById("selectedTagsCount");
  const activeFiltersContainer = document.getElementById("activeFilters");

  // Lightbox
  const lightbox = document.getElementById("lightbox");
  const lightboxImg = document.getElementById("lightboxImg");
  const lightboxTitle = document.getElementById("lightboxTitle");
  const lightboxTheme = document.getElementById("lightboxTheme");
  const lightboxTags = document.getElementById("lightboxTags");
  const lightboxClose = document.getElementById("lightboxClose");
  const lightboxPrev = document.getElementById("lightboxPrev");
  const lightboxNext = document.getElementById("lightboxNext");

  // Load data
  async function loadImages() {
    try {
      const response = await fetch("data/images.json");
      images = await response.json();

      // Extract unique themes and tags
      const themeSet = new Set();
      const tagSet = new Set();

      images.forEach((img) => {
        themeSet.add(img.theme);
        img.tags.forEach((tag) => tagSet.add(tag));
      });

      allThemes = Array.from(themeSet).sort();
      allTags = Array.from(tagSet).sort();

      renderFilters();
      renderGallery();
    } catch (error) {
      console.error("Failed to load images:", error);
      galleryGrid.innerHTML = '<div class="no-results"><h3>加载失败</h3><p>无法加载图片数据</p></div>';
    }
  }

  // Render theme filters
  function renderFilters() {
    // Theme chips
    const themeCounts = {};
    images.forEach((img) => {
      themeCounts[img.theme] = (themeCounts[img.theme] || 0) + 1;
    });

    // Add "All" chip
    themeFilters.innerHTML = `
            <button class="theme-chip ${!activeTheme ? "active" : ""}" data-theme="">
                全部 <span class="count">${images.length}</span>
            </button>
        `;

    allThemes.forEach((theme) => {
      const chip = document.createElement("button");
      chip.className = `theme-chip ${activeTheme === theme ? "active" : ""}`;
      chip.dataset.theme = theme;
      chip.innerHTML = `${theme} <span class="count">${themeCounts[theme]}</span>`;
      themeFilters.appendChild(chip);
    });

    // Tag chips
    tagFilters.innerHTML = "";
    allTags.forEach((tag) => {
      const chip = document.createElement("button");
      chip.className = `tag-chip ${activeTags.has(tag) ? "active" : ""}`;
      chip.dataset.tag = tag;
      chip.textContent = tag;
      tagFilters.appendChild(chip);
    });
  }

  // Render gallery
  function renderGallery() {
    filteredImages = images.filter((img) => {
      // Theme filter
      if (activeTheme && img.theme !== activeTheme) return false;

      // Tag filter
      if (activeTags.size > 0) {
        const imgTags = new Set(img.tags);
        if (filterMode === "AND") {
          for (const tag of activeTags) {
            if (!imgTags.has(tag)) return false;
          }
        } else {
          // OR mode
          let hasAny = false;
          for (const tag of activeTags) {
            if (imgTags.has(tag)) {
              hasAny = true;
              break;
            }
          }
          if (!hasAny) return false;
        }
      }

      // Search filter
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        const matchName = img.filename.toLowerCase().includes(query);
        const matchTheme = img.theme.toLowerCase().includes(query);
        const matchTags = img.tags.some((t) => t.toLowerCase().includes(query));
        if (!matchName && !matchTheme && !matchTags) return false;
      }

      return true;
    });

    // Update count
    imageCount.textContent = `显示 ${filteredImages.length} / ${images.length} 张图片`;
    selectedTagsCount.textContent =
      activeTags.size > 0 ? `(已选 ${activeTags.size} 个)` : "";

    // Render cards
    if (filteredImages.length === 0) {
      galleryGrid.innerHTML = `
                <div class="no-results">
                    <h3>未找到匹配的图片</h3>
                    <p>尝试调整筛选条件或清除筛选</p>
                </div>
            `;
      return;
    }

    galleryGrid.innerHTML = filteredImages
      .map(
        (img, index) => `
            <div class="image-card" data-index="${index}">
                <div class="image-wrapper">
                    <img src="images/${img.filename}" alt="${img.filename}" loading="lazy">
                </div>
                <div class="image-info">
                    <div class="image-name" title="${img.filename}">${img.filename}</div>
                    <div class="image-theme">${img.theme}</div>
                    <div class="image-tags">
                        ${img.tags
                          .slice(0, 3)
                          .map((t) => `<span class="image-tag">${t}</span>`)
                          .join("")}
                        ${img.tags.length > 3 ? `<span class="image-tag">+${img.tags.length - 3}</span>` : ""}
                    </div>
                </div>
            </div>
        `,
      )
      .join("");

    // Update active filters display
    renderActiveFilters();
  }

  // Render active filters
  function renderActiveFilters() {
    activeFiltersContainer.innerHTML = "";

    if (activeTheme) {
      const el = document.createElement("span");
      el.className = "active-filter";
      el.innerHTML = `主题: ${activeTheme} <button data-clear="theme">×</button>`;
      activeFiltersContainer.appendChild(el);
    }

    activeTags.forEach((tag) => {
      const el = document.createElement("span");
      el.className = "active-filter";
      el.innerHTML = `${tag} <button data-clear-tag="${tag}">×</button>`;
      activeFiltersContainer.appendChild(el);
    });
  }

  // Open lightbox
  function openLightbox(index) {
    if (index < 0 || index >= filteredImages.length) return;

    currentLightboxIndex = index;
    const img = filteredImages[index];

    lightboxImg.src = `images/${img.filename}`;
    lightboxTitle.textContent = img.filename;
    lightboxTheme.textContent = img.theme;
    lightboxTags.innerHTML = img.tags.map((t) => `<span>${t}</span>`).join("");

    lightbox.classList.add("active");
    document.body.style.overflow = "hidden";
  }

  // Close lightbox
  function closeLightbox() {
    lightbox.classList.remove("active");
    document.body.style.overflow = "";
    currentLightboxIndex = -1;
  }

  // Navigate lightbox
  function navigateLightbox(direction) {
    if (currentLightboxIndex < 0) return;

    let newIndex = currentLightboxIndex + direction;
    if (newIndex < 0) newIndex = filteredImages.length - 1;
    if (newIndex >= filteredImages.length) newIndex = 0;

    openLightbox(newIndex);
  }

  // Event Listeners

  // Theme filter
  themeFilters.addEventListener("click", (e) => {
    const chip = e.target.closest(".theme-chip");
    if (!chip) return;

    activeTheme = chip.dataset.theme || null;

    // Update UI
    themeFilters
      .querySelectorAll(".theme-chip")
      .forEach((c) => c.classList.remove("active"));
    chip.classList.add("active");

    renderGallery();
  });

  // Tag filter
  tagFilters.addEventListener("click", (e) => {
    const chip = e.target.closest(".tag-chip");
    if (!chip) return;

    const tag = chip.dataset.tag;
    if (activeTags.has(tag)) {
      activeTags.delete(tag);
      chip.classList.remove("active");
    } else {
      activeTags.add(tag);
      chip.classList.add("active");
    }

    renderGallery();
  });

  // Search
  searchInput.addEventListener("input", (e) => {
    searchQuery = e.target.value.trim();
    renderGallery();
  });

  // Filter mode
  modeAndBtn.addEventListener("click", () => {
    filterMode = "AND";
    modeAndBtn.classList.add("active");
    modeOrBtn.classList.remove("active");
    renderGallery();
  });

  modeOrBtn.addEventListener("click", () => {
    filterMode = "OR";
    modeOrBtn.classList.add("active");
    modeAndBtn.classList.remove("active");
    renderGallery();
  });

  // Clear filters
  clearBtn.addEventListener("click", () => {
    activeTheme = null;
    activeTags.clear();
    searchQuery = "";
    searchInput.value = "";

    themeFilters.querySelectorAll(".theme-chip").forEach((c, i) => {
      c.classList.toggle("active", i === 0);
    });
    tagFilters
      .querySelectorAll(".tag-chip")
      .forEach((c) => c.classList.remove("active"));

    renderGallery();
  });

  // Active filters removal
  activeFiltersContainer.addEventListener("click", (e) => {
    if (e.target.dataset.clear === "theme") {
      activeTheme = null;
      themeFilters.querySelectorAll(".theme-chip").forEach((c, i) => {
        c.classList.toggle("active", i === 0);
      });
      renderGallery();
    }

    const tagToClear = e.target.dataset.clearTag;
    if (tagToClear) {
      activeTags.delete(tagToClear);
      tagFilters
        .querySelector(`[data-tag="${tagToClear}"]`)
        ?.classList.remove("active");
      renderGallery();
    }
  });

  // Gallery click (open lightbox)
  galleryGrid.addEventListener("click", (e) => {
    const card = e.target.closest(".image-card");
    if (!card) return;

    openLightbox(parseInt(card.dataset.index));
  });

  // Lightbox controls
  lightboxClose.addEventListener("click", closeLightbox);
  lightboxPrev.addEventListener("click", () => navigateLightbox(-1));
  lightboxNext.addEventListener("click", () => navigateLightbox(1));

  lightbox.addEventListener("click", (e) => {
    if (e.target === lightbox) closeLightbox();
  });

  // Keyboard navigation
  document.addEventListener("keydown", (e) => {
    if (!lightbox.classList.contains("active")) return;

    if (e.key === "Escape") closeLightbox();
    if (e.key === "ArrowLeft") navigateLightbox(-1);
    if (e.key === "ArrowRight") navigateLightbox(1);
  });

  // Initialize
  loadImages();
})();
