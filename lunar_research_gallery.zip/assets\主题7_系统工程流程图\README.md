# 主题7_系统工程流程图
## Systems Engineering and Flowcharts

---

## 图片清单 (4 张)

| # | ID | 建议文件名 | 来源 | 年份 | 综合评分 |
|---|-----|-----------|------|------|---------|
| 1 | 7-SE-network_flow_NASA1988 | `7_network_flow_model_NASA_1988_Fig2.png` | NASA TM-88 | 1988 | 4.2 |
| 2 | 7-SE-tradespace_orbit_NASA2016 | `7_trajectory_tradespace_NASA_2016_Fig1.png` | NASA CR | 2016 | 4.0 |
| 3 | 7-SE-scanned-network_NASA2012 | `7_scanned_network_traffic_NASA_2012_Fig3.png` | NASA TDA Report 189C | 2012 | 3.8 |
| 4 | 7-SE-dsm_earth_NASA2014 | `7_distributed_space_mission_NASA_2014_Fig2.png` | NASA CR | 2014 | 3.8 |

---

## 详细信息

### 7-SE-network_flow_NASA1988

- **建议文件名**: `7_network_flow_model_NASA_1988_Fig2.png`
- **作者/机构**: NASA Transportation Office
- **年份**: 1988
- **论文标题**: A Space Transportation System Operations Model
- **期刊/会议**: NASA TM-88
- **图号**: Figure 2
- **来源链接**: [https://ntrs.nasa.gov/api/citations/19880005617/downloads/19880005617.pdf](https://ntrs.nasa.gov/api/citations/19880005617/downloads/19880005617.pdf)

**评分**:
- 科研质感: 4.0
- 信息密度: 4.0
- 可复刻性: 4.0
- 主题匹配: 4.0
- 来源可信度: 5.0
- **综合评分**: 4.2

---

### 7-SE-tradespace_orbit_NASA2016

- **建议文件名**: `7_trajectory_tradespace_NASA_2016_Fig1.png`
- **作者/机构**: J. Bradley & R. Cheng
- **年份**: 2016
- **论文标题**: Augmenting Conceptual Design Trajectory Tradespace Exploration
- **期刊/会议**: NASA CR
- **图号**: Figure 1
- **来源链接**: [https://ntrs.nasa.gov/api/citations/20160012096/downloads/20160012096.pdf](https://ntrs.nasa.gov/api/citations/20160012096/downloads/20160012096.pdf)

**评分**:
- 科研质感: 4.0
- 信息密度: 4.0
- 可复刻性: 3.0
- 主题匹配: 4.0
- 来源可信度: 5.0
- **综合评分**: 4.0

---

### 7-SE-scanned-network_NASA2012

- **建议文件名**: `7_scanned_network_traffic_NASA_2012_Fig3.png`
- **作者/机构**: L. Wood et al.
- **年份**: 2012
- **论文标题**: End-to-End Traffic Flow Modeling of Integrated SCaN Network
- **期刊/会议**: NASA TDA Report 189C
- **图号**: Figure 3
- **来源链接**: [https://tda.jpl.nasa.gov/progress_report/42-189/189C.pdf](https://tda.jpl.nasa.gov/progress_report/42-189/189C.pdf)

**评分**:
- 科研质感: 4.0
- 信息密度: 5.0
- 可复刻性: 2.0
- 主题匹配: 3.0
- 来源可信度: 5.0
- **综合评分**: 3.8

---

### 7-SE-dsm_earth_NASA2014

- **建议文件名**: `7_distributed_space_mission_NASA_2014_Fig2.png`
- **作者/机构**: C. Hinkle et al.
- **年份**: 2014
- **论文标题**: Distributed Space Mission Design using MBSE
- **期刊/会议**: NASA CR
- **图号**: Figure 2
- **来源链接**: [https://ntrs.nasa.gov/api/citations/20140016561/downloads/20140016561.pdf](https://ntrs.nasa.gov/api/citations/20140016561/downloads/20140016561.pdf)

**评分**:
- 科研质感: 4.0
- 信息密度: 4.0
- 可复刻性: 3.0
- 主题匹配: 3.0
- 来源可信度: 5.0
- **综合评分**: 3.8

---

