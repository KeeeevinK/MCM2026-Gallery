# 主题3_生命周期评估LCA
## Life Cycle Assessment (LCA)

---

## 图片清单 (6 张)

| # | ID | 建议文件名 | 来源 | 年份 | 综合评分 |
|---|-----|-----------|------|------|---------|
| 1 | 3-LCA-embodiedcarbon_MDPI2022 | `3_lca_embodied_carbon_MDPI_2022_Fig3.png` | Buildings 12(8) | 2022 | 4.2 |
| 2 | 3-LCA-bim-Hindawi2015 | `3_lca_carbon_bim_Hindawi_2015_Fig5.png` | AJSE/Hindawi | 2015 | 3.4 |
| 3 | 3-LCA-framework_Springer2021 | `3_lca_framework_Springer_2021_Fig2.png` | Sustainability 13(2) | 2021 | 4.0 |
| 4 | 3-LCA-visualization_MDPI2023 | `3_lca_visualization_tools_MDPI_2023_Fig6.png` | Sustainability 15(13) | 2023 | 4.8 |
| 5 | 3-LCA-stackedbar_Idaho2019 | `3_lca_stacked_biomass_UIdaho_2019_Fig8.png` | University of Idaho PhD | 2019 | 4.0 |
| 6 | 3-LCA-carbon_catalog_Nature2022 | `3_lca_carbon_product_Nature_2022_Fig1.png` | Nature/PMC | 2022 | 4.0 |

---

## 详细信息

### 3-LCA-embodiedcarbon_MDPI2022

- **建议文件名**: `3_lca_embodied_carbon_MDPI_2022_Fig3.png`
- **作者/机构**: L. Kubus et al.
- **年份**: 2022
- **论文标题**: Life Cycle Assessment of Embodied Carbon - High-Rise Residential
- **期刊/会议**: Buildings 12(8)
- **图号**: Figure 3
- **来源链接**: [https://www.mdpi.com/2075-5309/12/8/1203/pdf](https://www.mdpi.com/2075-5309/12/8/1203/pdf)

**评分**:
- 科研质感: 4.0
- 信息密度: 5.0
- 可复刻性: 4.0
- 主题匹配: 4.0
- 来源可信度: 4.0
- **综合评分**: 4.2

---

### 3-LCA-bim-Hindawi2015

- **建议文件名**: `3_lca_carbon_bim_Hindawi_2015_Fig5.png`
- **作者/机构**: Ding et al.
- **年份**: 2015
- **论文标题**: Case Study of Carbon Emissions from a Building's Life Cycle
- **期刊/会议**: AJSE/Hindawi
- **图号**: Figure 5
- **来源链接**: [http://downloads.hindawi.com/journals/amse/2015/954651.pdf](http://downloads.hindawi.com/journals/amse/2015/954651.pdf)

**评分**:
- 科研质感: 4.0
- 信息密度: 4.0
- 可复刻性: 3.0
- 主题匹配: 3.0
- 来源可信度: 3.0
- **综合评分**: 3.4

---

### 3-LCA-framework_Springer2021

- **建议文件名**: `3_lca_framework_Springer_2021_Fig2.png`
- **作者/机构**: I. Simão et al.
- **年份**: 2021
- **论文标题**: Life Cycle Assessment Framework for Embodied Environmental Impacts
- **期刊/会议**: Sustainability 13(2)
- **图号**: Figure 2
- **来源链接**: [https://www.mdpi.com/2071-1050/13/2/461/pdf](https://www.mdpi.com/2071-1050/13/2/461/pdf)

**评分**:
- 科研质感: 4.0
- 信息密度: 4.0
- 可复刻性: 4.0
- 主题匹配: 4.0
- 来源可信度: 4.0
- **综合评分**: 4.0

---

### 3-LCA-visualization_MDPI2023

- **建议文件名**: `3_lca_visualization_tools_MDPI_2023_Fig6.png`
- **作者/机构**: Helias & Fava
- **年份**: 2023
- **论文标题**: Visualization and Interpretation of LCSA - Existing Tools
- **期刊/会议**: Sustainability 15(13)
- **图号**: Figure 6
- **来源链接**: [https://www.mdpi.com/2071-1050/15/13/10658/pdf](https://www.mdpi.com/2071-1050/15/13/10658/pdf)

**评分**:
- 科研质感: 5.0
- 信息密度: 5.0
- 可复刻性: 4.0
- 主题匹配: 5.0
- 来源可信度: 5.0
- **综合评分**: 4.8

---

### 3-LCA-stackedbar_Idaho2019

- **建议文件名**: `3_lca_stacked_biomass_UIdaho_2019_Fig8.png`
- **作者/机构**: Y. Wan et al.
- **年份**: 2019
- **论文标题**: Life Cycle Assessment of Carbon Capture Membrane
- **期刊/会议**: University of Idaho PhD
- **图号**: Figure 8
- **来源链接**: [https://objects.lib.uidaho.edu/etd/pdf/Nilkar_idaho_0089N_12665.pdf](https://objects.lib.uidaho.edu/etd/pdf/Nilkar_idaho_0089N_12665.pdf)

**评分**:
- 科研质感: 4.0
- 信息密度: 5.0
- 可复刻性: 4.0
- 主题匹配: 4.0
- 来源可信度: 3.0
- **综合评分**: 4.0

---

### 3-LCA-carbon_catalog_Nature2022

- **建议文件名**: `3_lca_carbon_product_Nature_2022_Fig1.png`
- **作者/机构**: E. Ng et al.
- **年份**: 2022
- **论文标题**: The Carbon Catalogue - 866 Commercial Products PCF
- **期刊/会议**: Nature/PMC
- **图号**: Figure 1
- **来源链接**: [https://pmc.ncbi.nlm.nih.gov/articles/PMC8927124/](https://pmc.ncbi.nlm.nih.gov/articles/PMC8927124/)

**评分**:
- 科研质感: 4.0
- 信息密度: 5.0
- 可复刻性: 3.0
- 主题匹配: 3.0
- 来源可信度: 5.0
- **综合评分**: 4.0

---

