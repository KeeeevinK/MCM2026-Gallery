# 主题2_不确定性与敏感性分析
## Uncertainty and Sensitivity Analysis

---

## 图片清单 (7 张)

| # | ID | 建议文件名 | 来源 | 年份 | 综合评分 |
|---|-----|-----------|------|------|---------|
| 1 | 2-SA-sobol-VVUQ2025 | `2_sobol_sensitivity_reactor_ASME_2025_Fig3.png` | VVUQ2025 Conference | 2025 | 4.8 |
| 2 | 2-SA-sobol-solar-AGU2022 | `2_sobol_indices_solarwind_Wiley_2022_Fig2.png` | AGU/Wiley | 2022 | 4.4 |
| 3 | 2-FA-fanchart-CBR_2014 | `2_fanchart_inflation_CBR_2014_Fig2.png` | Central Bank Review | 2014 | 4.6 |
| 4 | 2-FA-fanplot-UNL2012 | `2_fanchart_boe_fanplot_UNL_2012_Fig3-5.png` | R Journal | 2012 | 4.6 |
| 5 | 2-RD-ridgeline_UCL2003 | `2_ridgeline_density_UCL_2003_Fig2.png` | UCL Technical Report | 2003 | 3.8 |
| 6 | 2-SA-sobol-sampling-Sandia_2023 | `2_sobol_sampling_comparison_Sandia_2023_Fig3.png` | Sandia Labs Report | 2023 | 4.6 |
| 7 | 2-MC-tornado-LinkedIn2025 | `2_tornado_sensitivity_LinkedIn_2025_Fig1.png` | LinkedIn Article | 2025 | 3.4 |

---

## 详细信息

### 2-SA-sobol-VVUQ2025

- **建议文件名**: `2_sobol_sensitivity_reactor_ASME_2025_Fig3.png`
- **作者/机构**: M. Rausch et al.
- **年份**: 2025
- **论文标题**: Sensitivity Analysis and Uncertainty Quantification of a Digital Twin
- **期刊/会议**: VVUQ2025 Conference
- **图号**: Figure 3
- **来源链接**: [https://asmedigitalcollection.asme.org/VVS/proceedings/VVUQ2025/88742/V001T01A003/1219407](https://asmedigitalcollection.asme.org/VVS/proceedings/VVUQ2025/88742/V001T01A003/1219407)

**评分**:
- 科研质感: 5.0
- 信息密度: 5.0
- 可复刻性: 4.0
- 主题匹配: 5.0
- 来源可信度: 5.0
- **综合评分**: 4.8

---

### 2-SA-sobol-solar-AGU2022

- **建议文件名**: `2_sobol_indices_solarwind_Wiley_2022_Fig2.png`
- **作者/机构**: A. Consortium et al.
- **年份**: 2022
- **论文标题**: Global Sensitivity Analysis for Background Solar Wind
- **期刊/会议**: AGU/Wiley
- **图号**: Figure 2
- **来源链接**: [https://agupubs.onlinelibrary.wiley.com/doi/10.1029/2022SW003262](https://agupubs.onlinelibrary.wiley.com/doi/10.1029/2022SW003262)

**评分**:
- 科研质感: 5.0
- 信息密度: 4.0
- 可复刻性: 4.0
- 主题匹配: 4.0
- 来源可信度: 5.0
- **综合评分**: 4.4

---

### 2-FA-fanchart-CBR_2014

- **建议文件名**: `2_fanchart_inflation_CBR_2014_Fig2.png`
- **作者/机构**: Bratu/CBR Romania
- **年份**: 2014
- **论文标题**: Fan chart or Monte Carlo simulations for assessing forecast uncertainty
- **期刊/会议**: Central Bank Review
- **图号**: Figure 2
- **来源链接**: [https://hrcak.srce.hr/file/252816](https://hrcak.srce.hr/file/252816)

**评分**:
- 科研质感: 4.0
- 信息密度: 5.0
- 可复刻性: 5.0
- 主题匹配: 5.0
- 来源可信度: 4.0
- **综合评分**: 4.6

---

### 2-FA-fanplot-UNL2012

- **建议文件名**: `2_fanchart_boe_fanplot_UNL_2012_Fig3-5.png`
- **作者/机构**: Ellis & Smith
- **年份**: 2012
- **论文标题**: fanplot: An R Package for Visualising Sequential Distributions
- **期刊/会议**: R Journal
- **图号**: Figures 3-5
- **来源链接**: [https://digitalcommons.unl.edu/cgi/viewcontent.cgi?article=1451&context=r-journal](https://digitalcommons.unl.edu/cgi/viewcontent.cgi?article=1451&context=r-journal)

**评分**:
- 科研质感: 5.0
- 信息密度: 5.0
- 可复刻性: 5.0
- 主题匹配: 4.0
- 来源可信度: 4.0
- **综合评分**: 4.6

---

### 2-RD-ridgeline_UCL2003

- **建议文件名**: `2_ridgeline_density_UCL_2003_Fig2.png`
- **作者/机构**: Hennig & Christmann
- **年份**: 2003
- **论文标题**: Ridgeline plot and clusterwise stability as tools for merging
- **期刊/会议**: UCL Technical Report
- **图号**: Figure 2
- **来源链接**: [http://www.homepages.ucl.ac.uk/~ucakche/papers/hennigmergeifcs.pdf](http://www.homepages.ucl.ac.uk/~ucakche/papers/hennigmergeifcs.pdf)

**评分**:
- 科研质感: 4.0
- 信息密度: 4.0
- 可复刻性: 4.0
- 主题匹配: 3.0
- 来源可信度: 4.0
- **综合评分**: 3.8

---

### 2-SA-sobol-sampling-Sandia_2023

- **建议文件名**: `2_sobol_sampling_comparison_Sandia_2023_Fig3.png`
- **作者/机构**: Rausch & Sanders
- **年份**: 2023
- **论文标题**: Sensitivity Analysis and Uncertainty Quantification using Dakota
- **期刊/会议**: Sandia Labs Report
- **图号**: Figure 3
- **来源链接**: [https://www.sandia.gov/app/uploads/sites/241/2023/04/DakotaTraining_SensitivityAnalysis.pdf](https://www.sandia.gov/app/uploads/sites/241/2023/04/DakotaTraining_SensitivityAnalysis.pdf)

**评分**:
- 科研质感: 4.0
- 信息密度: 4.0
- 可复刻性: 5.0
- 主题匹配: 5.0
- 来源可信度: 5.0
- **综合评分**: 4.6

---

### 2-MC-tornado-LinkedIn2025

- **建议文件名**: `2_tornado_sensitivity_LinkedIn_2025_Fig1.png`
- **作者/机构**: D. Carvalho
- **年份**: 2025
- **论文标题**: Decoding Monte Carlo Simulation Results
- **期刊/会议**: LinkedIn Article
- **图号**: Figure 1
- **来源链接**: [https://www.linkedin.com/pulse/decoding-monte-carlo-simulation-results-complete-guide-carvalho--ij26f](https://www.linkedin.com/pulse/decoding-monte-carlo-simulation-results-complete-guide-carvalho--ij26f)

**评分**:
- 科研质感: 3.0
- 信息密度: 4.0
- 可复刻性: 4.0
- 主题匹配: 4.0
- 来源可信度: 2.0
- **综合评分**: 3.4

---

