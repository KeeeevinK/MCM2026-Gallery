# 图片资源分类汇总报告
## Image Inventory Classification Summary

**生成日期**: 2026-02-01 21:08
**来源文件**: `image_inventory_lunar.md`
**总图片数**: 42 张
**主题分类**: 7 类

---

## 分类统计

| 主题 | 英文名称 | 图片数量 | 文件夹 |
|------|---------|---------|--------|
| 主题1 | Multi-Objective Pareto Visualization | 8 | `主题1_多目标优化Pareto前沿/` |
| 主题2 | Uncertainty and Sensitivity Analysis | 7 | `主题2_不确定性与敏感性分析/` |
| 主题3 | Life Cycle Assessment (LCA) | 6 | `主题3_生命周期评估LCA/` |
| 主题4 | Rocket vs Space Elevator Cost Benchmarking | 5 | `主题4_火箭太空电梯成本对标/` |
| 主题5 | Technology Readiness and Feasibility Matrix | 6 | `主题5_技术成熟度可行性矩阵/` |
| 主题6 | Lunar Base Logistics and Transportation Network | 6 | `主题6_月球基地物流运输网络/` |
| 主题7 | Systems Engineering and Flowcharts | 4 | `主题7_系统工程流程图/` |

**总计**: 42 张图片

---

## 文件夹结构

```
images_by_theme/
├── 主题1_多目标优化Pareto前沿/
│   ├── README.md          # 主题索引
│   └── metadata.json      # 元数据 (8 条)
├── 主题2_不确定性与敏感性分析/
│   ├── README.md          # 主题索引
│   └── metadata.json      # 元数据 (7 条)
├── 主题3_生命周期评估LCA/
│   ├── README.md          # 主题索引
│   └── metadata.json      # 元数据 (6 条)
├── 主题4_火箭太空电梯成本对标/
│   ├── README.md          # 主题索引
│   └── metadata.json      # 元数据 (5 条)
├── 主题5_技术成熟度可行性矩阵/
│   ├── README.md          # 主题索引
│   └── metadata.json      # 元数据 (6 条)
├── 主题6_月球基地物流运输网络/
│   ├── README.md          # 主题索引
│   └── metadata.json      # 元数据 (6 条)
├── 主题7_系统工程流程图/
│   ├── README.md          # 主题索引
│   └── metadata.json      # 元数据 (4 条)
└── SUMMARY.md              # 本汇总报告
```

---

## 使用说明

1. 每个主题文件夹包含:
   - `README.md`: 该主题的图片详细信息索引
   - `metadata.json`: 图片元数据（可供程序读取）

2. 图片来源链接已包含在各索引文件中，可直接点击访问原始来源

3. 评分说明:
   - 科研质感 (1-5): 图表的学术专业程度
   - 信息密度 (1-5): 单位面积的信息量
   - 可复刻性 (1-5): 是否容易复现类似效果
   - 主题匹配 (1-5): 与月球基地运输论文的相关度
   - 来源可信度 (1-5): 出版机构的权威性
