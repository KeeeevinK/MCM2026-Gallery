# 主题6_月球基地物流运输网络
## Lunar Base Logistics and Transportation Network

---

## 图片清单 (6 张)

| # | ID | 建议文件名 | 来源 | 年份 | 综合评分 |
|---|-----|-----------|------|------|---------|
| 1 | 6-LUNAR-logistics_NASA2008 | `6_lunar_logistics_flow_NASA_2008_Fig1.png` | NASA TM-2008-215150 | 2008 | 5.0 |
| 2 | 6-LUNAR-flare_acta2020 | `6_lunar_flare_architecture_Acta_2020_Fig3.png` | Acta Astronautica 177 | 2020 | 4.2 |
| 3 | 6-LUNAR-isru_water_arXiv2024 | `6_lunar_water_management_arXiv_2024_Fig2.png` | arXiv:2405.14100 | 2024 | 4.0 |
| 4 | 6-SUPPLY-multimodal_Utrecht2012 | `6_multimodal_network_optimization_Utrecht_2012_Fig3.png` | Proc. WCTR | 2012 | 4.4 |
| 5 | 6-SUPPLY-satellite_cislunar_AIAA2018 | `6_cislunar_supply_pareto_AIAA_2018_Fig1.png` | AIAA/J. Guidance | 2018 | 4.4 |
| 6 | 6-SPACE-elevator_arch_NSS2021 | `6_space_elevator_architecture_NSS_2021_Fig4.png` | NSS Report | 2021 | 4.8 |

---

## 详细信息

### 6-LUNAR-logistics_NASA2008

- **建议文件名**: `6_lunar_logistics_flow_NASA_2008_Fig1.png`
- **作者/机构**: S. Hill et al.
- **年份**: 2008
- **论文标题**: Logistics Modeling for Lunar Exploration Systems
- **期刊/会议**: NASA TM-2008-215150
- **图号**: Figure 1
- **来源链接**: [https://ntrs.nasa.gov/api/citations/20080040158/downloads/20080040158.pdf](https://ntrs.nasa.gov/api/citations/20080040158/downloads/20080040158.pdf)

**评分**:
- 科研质感: 5.0
- 信息密度: 5.0
- 可复刻性: 5.0
- 主题匹配: 5.0
- 来源可信度: 5.0
- **综合评分**: 5.0

---

### 6-LUNAR-flare_acta2020

- **建议文件名**: `6_lunar_flare_architecture_Acta_2020_Fig3.png`
- **作者/机构**: M. Evans
- **年份**: 2020
- **论文标题**: A Flexible Lunar Architecture for Exploration (FLARE)
- **期刊/会议**: Acta Astronautica 177
- **图号**: Figure 3
- **来源链接**: [https://pmc.ncbi.nlm.nih.gov/articles/PMC7385728/](https://pmc.ncbi.nlm.nih.gov/articles/PMC7385728/)

**评分**:
- 科研质感: 4.0
- 信息密度: 4.0
- 可复刻性: 3.0
- 主题匹配: 5.0
- 来源可信度: 5.0
- **综合评分**: 4.2

---

### 6-LUNAR-isru_water_arXiv2024

- **建议文件名**: `6_lunar_water_management_arXiv_2024_Fig2.png`
- **作者/机构**: G. Brown et al.
- **年份**: 2024
- **论文标题**: Water Management for Self-Sustaining Moonbase
- **期刊/会议**: arXiv:2405.14100
- **图号**: Figure 2
- **来源链接**: [https://arxiv.org/pdf/2405.14100.pdf](https://arxiv.org/pdf/2405.14100.pdf)

**评分**:
- 科研质感: 4.0
- 信息密度: 4.0
- 可复刻性: 3.0
- 主题匹配: 5.0
- 来源可信度: 4.0
- **综合评分**: 4.0

---

### 6-SUPPLY-multimodal_Utrecht2012

- **建议文件名**: `6_multimodal_network_optimization_Utrecht_2012_Fig3.png`
- **作者/机构**: S. Brands & E. Viegas
- **年份**: 2012
- **论文标题**: Multi-objective optimization of multimodal transportation networks
- **期刊/会议**: Proc. WCTR
- **图号**: Figure 3
- **来源链接**: [https://ris.utwente.nl/ws/files/5425116/brands_2012.pdf](https://ris.utwente.nl/ws/files/5425116/brands_2012.pdf)

**评分**:
- 科研质感: 5.0
- 信息密度: 5.0
- 可复刻性: 4.0
- 主题匹配: 4.0
- 来源可信度: 4.0
- **综合评分**: 4.4

---

### 6-SUPPLY-satellite_cislunar_AIAA2018

- **建议文件名**: `6_cislunar_supply_pareto_AIAA_2018_Fig1.png`
- **作者/机构**: J. Vallado et al.
- **年份**: 2018
- **论文标题**: Optimization of In-Space Supply Chain Design
- **期刊/会议**: AIAA/J. Guidance
- **图号**: Figure 1
- **来源链接**: [https://arc.aiaa.org/doi/10.2514/1.A34042](https://arc.aiaa.org/doi/10.2514/1.A34042)

**评分**:
- 科研质感: 4.0
- 信息密度: 5.0
- 可复刻性: 3.0
- 主题匹配: 5.0
- 来源可信度: 5.0
- **综合评分**: 4.4

---

### 6-SPACE-elevator_arch_NSS2021

- **建议文件名**: `6_space_elevator_architecture_NSS_2021_Fig4.png`
- **作者/机构**: J. Raitt et al.
- **年份**: 2021
- **论文标题**: Space Elevator Systems Architecture
- **期刊/会议**: NSS Report
- **图号**: Figure 4.3
- **来源链接**: [https://nss.org/wp-content/uploads/Space-Elevator-Systems-Architecture.pdf](https://nss.org/wp-content/uploads/Space-Elevator-Systems-Architecture.pdf)

**评分**:
- 科研质感: 5.0
- 信息密度: 5.0
- 可复刻性: 4.0
- 主题匹配: 5.0
- 来源可信度: 5.0
- **综合评分**: 4.8

---

