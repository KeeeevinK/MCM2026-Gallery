# 主题1_多目标优化Pareto前沿
## Multi-Objective Pareto Visualization

---

## 图片清单 (8 张)

| # | ID | 建议文件名 | 来源 | 年份 | 综合评分 |
|---|-----|-----------|------|------|---------|
| 1 | 1-MO-Deb-2021 | `1_pareto_isom_visualization_MSU_2021_Fig2.png` | COIN Report 2021019 | 2021 | 5.0 |
| 2 | 1-MO-Deb-2021B | `1_pareto_isom_componentplanes_MSU_2021_Fig3.png` | COIN Report 2021019 | 2021 | 4.8 |
| 3 | 1-MO-Deb-2021C | `1_pareto_clustermap_MSU_2021_Fig4.png` | COIN Report 2021019 | 2021 | 4.4 |
| 4 | 1-MO-Ishibuchi-2016 | `1_pareto_dtlz_manifold_Osaka_2016_Fig1.png` | CEC2016 | 2016 | 4.2 |
| 5 | 1-MO-Ishibuchi-2016B | `1_pareto_parallel_coordinates_Osaka_2016_Fig7-9.png` | CEC2016 | 2016 | 4.2 |
| 6 | 1-MO-Li-2024 | `1_pareto_building_optimization_MDPI_2024_Fig5.png` | Buildings (MDPI) 14(7) | 2024 | 4.2 |
| 7 | 1-MO-uam-2025 | `1_pareto_uam_corridors_MDPI_2025_Fig8.png` | Aerospace 12(3) | 2025 | 4.4 |
| 8 | 1-MO-RadViz3D-2023 | `1_pareto_3d_radviz_academia_2023_Fig2.png` | Academia.edu | 2023 | 3.8 |

---

## 详细信息

### 1-MO-Deb-2021

- **建议文件名**: `1_pareto_isom_visualization_MSU_2021_Fig2.png`
- **作者/机构**: Kalyanmoy Deb et al.
- **年份**: 2021
- **论文标题**: Visualization and Analysis of Pareto-optimal Fronts using iSOM
- **期刊/会议**: COIN Report 2021019
- **图号**: Figure 2
- **来源链接**: [https://www.egr.msu.edu/~kdeb/papers/c2021019.pdf](https://www.egr.msu.edu/~kdeb/papers/c2021019.pdf)

**评分**:
- 科研质感: 5.0
- 信息密度: 5.0
- 可复刻性: 5.0
- 主题匹配: 5.0
- 来源可信度: 5.0
- **综合评分**: 5.0

---

### 1-MO-Deb-2021B

- **建议文件名**: `1_pareto_isom_componentplanes_MSU_2021_Fig3.png`
- **作者/机构**: Kalyanmoy Deb et al.
- **年份**: 2021
- **论文标题**: Visualization and Analysis of Pareto-optimal Fronts using iSOM
- **期刊/会议**: COIN Report 2021019
- **图号**: Figure 3
- **来源链接**: [https://www.egr.msu.edu/~kdeb/papers/c2021019.pdf](https://www.egr.msu.edu/~kdeb/papers/c2021019.pdf)

**评分**:
- 科研质感: 5.0
- 信息密度: 5.0
- 可复刻性: 5.0
- 主题匹配: 4.0
- 来源可信度: 5.0
- **综合评分**: 4.8

---

### 1-MO-Deb-2021C

- **建议文件名**: `1_pareto_clustermap_MSU_2021_Fig4.png`
- **作者/机构**: Kalyanmoy Deb et al.
- **年份**: 2021
- **论文标题**: Visualization and Analysis of Pareto-optimal Fronts using iSOM
- **期刊/会议**: COIN Report 2021019
- **图号**: Figure 4
- **来源链接**: [https://www.egr.msu.edu/~kdeb/papers/c2021019.pdf](https://www.egr.msu.edu/~kdeb/papers/c2021019.pdf)

**评分**:
- 科研质感: 5.0
- 信息密度: 4.0
- 可复刻性: 4.0
- 主题匹配: 4.0
- 来源可信度: 5.0
- **综合评分**: 4.4

---

### 1-MO-Ishibuchi-2016

- **建议文件名**: `1_pareto_dtlz_manifold_Osaka_2016_Fig1.png`
- **作者/机构**: Hisao Ishibuchi et al.
- **年份**: 2016
- **论文标题**: Performance Comparison of NSGA-II and NSGA-III
- **期刊/会议**: CEC2016
- **图号**: Figure 1
- **来源链接**: [https://ci-labo-omu.github.io/assets/paper/pdf_file/multiobjective/CEC2016_NSGA-III_Final.pdf](https://ci-labo-omu.github.io/assets/paper/pdf_file/multiobjective/CEC2016_NSGA-III_Final.pdf)

**评分**:
- 科研质感: 4.0
- 信息密度: 4.0
- 可复刻性: 5.0
- 主题匹配: 4.0
- 来源可信度: 4.0
- **综合评分**: 4.2

---

### 1-MO-Ishibuchi-2016B

- **建议文件名**: `1_pareto_parallel_coordinates_Osaka_2016_Fig7-9.png`
- **作者/机构**: Hisao Ishibuchi et al.
- **年份**: 2016
- **论文标题**: Performance Comparison of NSGA-II and NSGA-III
- **期刊/会议**: CEC2016
- **图号**: Figures 7-9
- **来源链接**: [https://ci-labo-omu.github.io/assets/paper/pdf_file/multiobjective/CEC2016_NSGA-III_Final.pdf](https://ci-labo-omu.github.io/assets/paper/pdf_file/multiobjective/CEC2016_NSGA-III_Final.pdf)

**评分**:
- 科研质感: 4.0
- 信息密度: 5.0
- 可复刻性: 4.0
- 主题匹配: 4.0
- 来源可信度: 4.0
- **综合评分**: 4.2

---

### 1-MO-Li-2024

- **建议文件名**: `1_pareto_building_optimization_MDPI_2024_Fig5.png`
- **作者/机构**: Hongbo Li et al.
- **年份**: 2024
- **论文标题**: Multi-Objective Optimization in Construction Project Management Based on NSGA-III
- **期刊/会议**: Buildings (MDPI) 14(7)
- **图号**: Figure 5
- **来源链接**: [https://www.mdpi.com/2075-5309/14/7/2112](https://www.mdpi.com/2075-5309/14/7/2112)

**评分**:
- 科研质感: 5.0
- 信息密度: 4.0
- 可复刻性: 4.0
- 主题匹配: 3.0
- 来源可信度: 5.0
- **综合评分**: 4.2

---

### 1-MO-uam-2025

- **建议文件名**: `1_pareto_uam_corridors_MDPI_2025_Fig8.png`
- **作者/机构**: Chao Sun et al.
- **年份**: 2025
- **论文标题**: Designing an Urban Air Mobility Corridor Network using U-NSGA-III
- **期刊/会议**: Aerospace 12(3)
- **图号**: Figure 8
- **来源链接**: [https://www.mdpi.com/2226-4310/12/3/229](https://www.mdpi.com/2226-4310/12/3/229)

**评分**:
- 科研质感: 5.0
- 信息密度: 5.0
- 可复刻性: 4.0
- 主题匹配: 3.0
- 来源可信度: 5.0
- **综合评分**: 4.4

---

### 1-MO-RadViz3D-2023

- **建议文件名**: `1_pareto_3d_radviz_academia_2023_Fig2.png`
- **作者/机构**: Unknown (RadViz variant)
- **年份**: 2023
- **论文标题**: 3D-RadVis: Visualization of Pareto front in many-objective optimization
- **期刊/会议**: Academia.edu
- **图号**: Figure 2
- **来源链接**: [https://www.academia.edu/97813533/3D_RadVis_Visualization_of_Pareto_front_in_many_objective_optimization](https://www.academia.edu/97813533/3D_RadVis_Visualization_of_Pareto_front_in_many_objective_optimization)

**评分**:
- 科研质感: 4.0
- 信息密度: 5.0
- 可复刻性: 3.0
- 主题匹配: 4.0
- 来源可信度: 3.0
- **综合评分**: 3.8

---

