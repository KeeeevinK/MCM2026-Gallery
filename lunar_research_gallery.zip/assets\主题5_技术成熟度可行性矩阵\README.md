# 主题5_技术成熟度可行性矩阵
## Technology Readiness and Feasibility Matrix

---

## 图片清单 (6 张)

| # | ID | 建议文件名 | 来源 | 年份 | 综合评分 |
|---|-----|-----------|------|------|---------|
| 1 | 5-TRL-guidebook_DoD2025 | `5_trl_scale_DoD_2025_Fig1.png` | DoD Official | 2025 | 4.8 |
| 2 | 5-TRL-screening_CMU2002 | `5_trl_decision_flow_CMU_2002_Fig3.png` | CMU/SEI | 2002 | 4.0 |
| 3 | 5-FHWA-trl_assessment_2017 | `5_trl_assessment_FHWA_2017_Fig2.png` | FHWA Guidelines | 2017 | 4.0 |
| 4 | 5-TRADESPACE-atsv_visual_Penn2007 | `5_tradespace_3d_atsv_Penn_2007_Fig4.png` | AIAA-2007-1878 | 2007 | 4.6 |
| 5 | 5-TRADESPACE-ross_apollo_MIT2010 | `5_tradespace_satellite_MIT_2010_Fig5.png` | AIAA-2010 | 2010 | 3.6 |
| 6 | 5-FEASIBILITY-suas_aiaa2023 | `5_feasibility_pareto_suas_AIAA_2023_Fig2.png` | AIAA | 2023 | 4.4 |

---

## 详细信息

### 5-TRL-guidebook_DoD2025

- **建议文件名**: `5_trl_scale_DoD_2025_Fig1.png`
- **作者/机构**: USD(R&E)
- **年份**: 2025
- **论文标题**: Technology Readiness Assessment Guidebook
- **期刊/会议**: DoD Official
- **图号**: Figure 1
- **来源链接**: [https://www.cto.mil/wp-content/uploads/2025/03/TRA-Guide-Feb2025.v2-Cleared.pdf](https://www.cto.mil/wp-content/uploads/2025/03/TRA-Guide-Feb2025.v2-Cleared.pdf)

**评分**:
- 科研质感: 5.0
- 信息密度: 4.0
- 可复刻性: 5.0
- 主题匹配: 5.0
- 来源可信度: 5.0
- **综合评分**: 4.8

---

### 5-TRL-screening_CMU2002

- **建议文件名**: `5_trl_decision_flow_CMU_2002_Fig3.png`
- **作者/机构**: M. Brown et al.
- **年份**: 2002
- **论文标题**: Using TRL Scale to Support Technology Screening
- **期刊/会议**: CMU/SEI
- **图号**: Figure 3
- **来源链接**: [https://www.sei.cmu.edu/asset_files/specialreport/2002_003_001_13931.pdf](https://www.sei.cmu.edu/asset_files/specialreport/2002_003_001_13931.pdf)

**评分**:
- 科研质感: 4.0
- 信息密度: 4.0
- 可复刻性: 4.0
- 主题匹配: 4.0
- 来源可信度: 4.0
- **综合评分**: 4.0

---

### 5-FHWA-trl_assessment_2017

- **建议文件名**: `5_trl_assessment_FHWA_2017_Fig2.png`
- **作者/机构**: FHWA
- **年份**: 2017
- **论文标题**: Technology Readiness Level Assessment
- **期刊/会议**: FHWA Guidelines
- **图号**: Figure 2
- **来源链接**: [https://www.fhwa.dot.gov/publications/research/ear/17047/17047.pdf](https://www.fhwa.dot.gov/publications/research/ear/17047/17047.pdf)

**评分**:
- 科研质感: 4.0
- 信息密度: 3.0
- 可复刻性: 4.0
- 主题匹配: 4.0
- 来源可信度: 5.0
- **综合评分**: 4.0

---

### 5-TRADESPACE-atsv_visual_Penn2007

- **建议文件名**: `5_tradespace_3d_atsv_Penn_2007_Fig4.png`
- **作者/机构**: Gary et al.
- **年份**: 2007
- **论文标题**: Advanced Visualization Techniques for Trade Space Exploration
- **期刊/会议**: AIAA-2007-1878
- **图号**: Figure 4
- **来源链接**: [https://www.atsv.psu.edu/webdocs/AIAA-2007-1878-108.pdf](https://www.atsv.psu.edu/webdocs/AIAA-2007-1878-108.pdf)

**评分**:
- 科研质感: 5.0
- 信息密度: 5.0
- 可复刻性: 4.0
- 主题匹配: 4.0
- 来源可信度: 5.0
- **综合评分**: 4.6

---

### 5-TRADESPACE-ross_apollo_MIT2010

- **建议文件名**: `5_tradespace_satellite_MIT_2010_Fig5.png`
- **作者/机构**: D. Ross et al.
- **年份**: 2010
- **论文标题**: Revisiting the Tradespace Exploration Paradigm
- **期刊/会议**: AIAA-2010
- **图号**: Figure 5
- **来源链接**: [https://seari.mit.edu/documents/preprints/ROSS_TSE_AIAA10.pdf](https://seari.mit.edu/documents/preprints/ROSS_TSE_AIAA10.pdf)

**评分**:
- 科研质感: 4.0
- 信息密度: 4.0
- 可复刻性: 3.0
- 主题匹配: 3.0
- 来源可信度: 4.0
- **综合评分**: 3.6

---

### 5-FEASIBILITY-suas_aiaa2023

- **建议文件名**: `5_feasibility_pareto_suas_AIAA_2023_Fig2.png`
- **作者/机构**: B. Sells et al.
- **年份**: 2023
- **论文标题**: Optimization and Decision-Making Framework for Small UAS
- **期刊/会议**: AIAA
- **图号**: Figure 2
- **来源链接**: [https://arc.aiaa.org/doi/10.2514/1.C036330](https://arc.aiaa.org/doi/10.2514/1.C036330)

**评分**:
- 科研质感: 5.0
- 信息密度: 5.0
- 可复刻性: 4.0
- 主题匹配: 3.0
- 来源可信度: 5.0
- **综合评分**: 4.4

---

