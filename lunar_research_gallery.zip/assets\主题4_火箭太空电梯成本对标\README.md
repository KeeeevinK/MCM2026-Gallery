# 主题4_火箭太空电梯成本对标
## Rocket vs Space Elevator Cost Benchmarking

---

## 图片清单 (5 张)

| # | ID | 建议文件名 | 来源 | 年份 | 综合评分 |
|---|-----|-----------|------|------|---------|
| 1 | 4-COST-rockets_dataset_arXiv2023 | `4_rocket_launch_costs_arXiv_2023_Table1.png` | arXiv:2310.05994 | 2023 | 4.8 |
| 2 | 4-COST-rocket_comparison_web2023 | `4_rocket_cost_comparison_tech_2023_Fig1.png` | SpaceInsider Blog | 2023 | 4.2 |
| 3 | 4-COST-elevator_economics_Wiki2004 | `4_space_elevator_cost_Wikipedia_2004_Table1.png` | Wikipedia/Edwards Proposal | 2004 | 3.8 |
| 4 | 4-COST-owid_trends_2025 | `4_launch_cost_trends_OurWorldData_2025_Fig1.png` | Our World in Data | 2025 | 4.6 |
| 5 | 4-COST-spaceline_arXiv2019 | `4_spaceline_practical_elevator_arXiv_2019_Fig2.png` | arXiv:1908.09339 | 2019 | 3.2 |

---

## 详细信息

### 4-COST-rockets_dataset_arXiv2023

- **建议文件名**: `4_rocket_launch_costs_arXiv_2023_Table1.png`
- **作者/机构**: B. Ho & M. Li
- **年份**: 2023
- **论文标题**: Launch Vehicle High-Energy Performance Dataset
- **期刊/会议**: arXiv:2310.05994
- **图号**: Table 1
- **来源链接**: [http://arxiv.org/pdf/2310.05994.pdf](http://arxiv.org/pdf/2310.05994.pdf)

**评分**:
- 科研质感: 5.0
- 信息密度: 5.0
- 可复刻性: 5.0
- 主题匹配: 5.0
- 来源可信度: 4.0
- **综合评分**: 4.8

---

### 4-COST-rocket_comparison_web2023

- **建议文件名**: `4_rocket_cost_comparison_tech_2023_Fig1.png`
- **作者/机构**: SpaceInsider Tech
- **年份**: 2023
- **论文标题**: How Much Does It Cost to Launch a Rocket?
- **期刊/会议**: SpaceInsider Blog
- **图号**: Figure 1
- **来源链接**: [https://spaceinsider.tech/2023/08/16/how-much-does-it-cost-to-launch-a-rocket/](https://spaceinsider.tech/2023/08/16/how-much-does-it-cost-to-launch-a-rocket/)

**评分**:
- 科研质感: 4.0
- 信息密度: 5.0
- 可复刻性: 4.0
- 主题匹配: 5.0
- 来源可信度: 3.0
- **综合评分**: 4.2

---

### 4-COST-elevator_economics_Wiki2004

- **建议文件名**: `4_space_elevator_cost_Wikipedia_2004_Table1.png`
- **作者/机构**: Wikipedia
- **年份**: 2004
- **论文标题**: Space elevator economics
- **期刊/会议**: Wikipedia/Edwards Proposal
- **图号**: Table
- **来源链接**: [https://en.wikipedia.org/wiki/Space_elevator_economics](https://en.wikipedia.org/wiki/Space_elevator_economics)

**评分**:
- 科研质感: 3.0
- 信息密度: 4.0
- 可复刻性: 4.0
- 主题匹配: 5.0
- 来源可信度: 3.0
- **综合评分**: 3.8

---

### 4-COST-owid_trends_2025

- **建议文件名**: `4_launch_cost_trends_OurWorldData_2025_Fig1.png`
- **作者/机构**: Our World in Data
- **年份**: 2025
- **论文标题**: Cost of space launches to low Earth orbit
- **期刊/会议**: Our World in Data
- **图号**: Figure 1
- **来源链接**: [https://ourworldindata.org/grapher/cost-space-launches-low-earth-orbit](https://ourworldindata.org/grapher/cost-space-launches-low-earth-orbit)

**评分**:
- 科研质感: 5.0
- 信息密度: 4.0
- 可复刻性: 5.0
- 主题匹配: 4.0
- 来源可信度: 5.0
- **综合评分**: 4.6

---

### 4-COST-spaceline_arXiv2019

- **建议文件名**: `4_spaceline_practical_elevator_arXiv_2019_Fig2.png`
- **作者/机构**: R. Freeland et al.
- **年份**: 2019
- **论文标题**: The Spaceline: practical space elevator alternative
- **期刊/会议**: arXiv:1908.09339
- **图号**: Figure 2
- **来源链接**: [https://arxiv.org/pdf/1908.09339.pdf](https://arxiv.org/pdf/1908.09339.pdf)

**评分**:
- 科研质感: 3.0
- 信息密度: 3.0
- 可复刻性: 2.0
- 主题匹配: 5.0
- 来源可信度: 3.0
- **综合评分**: 3.2

---

